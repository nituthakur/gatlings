package looping

import scala.concurrent.duration._

import io.gatling.core.Predef._
import io.gatling.http.Predef._
import io.gatling.jdbc.Predef._

class DuringExample extends Simulation {

	val httpProtocol = http
		.baseURL("http://newtours.demoaut.com")
		.inferHtmlResources(BlackList(""".*\.js""", """.*\.css""", """.*\.gif""", """.*\.jpeg""", """.*\.jpg""", """.*\.ico""", """.*\.woff""", """.*\.(t|o)tf""", """.*\.png"""), WhiteList())
		.acceptHeader("text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8")
		.acceptEncodingHeader("gzip, deflate")
		.acceptLanguageHeader("en-US,en;q=0.5")
		.userAgentHeader("Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:46.0) Gecko/20100101 Firefox/46.0")

	val headers_1 = Map("Accept" -> "image/png,image/*;q=0.8,*/*;q=0.5")



	val scn1 = scenario("DuringExample")
		// Landingpage
		.exec(http("request_0")
			.get("/mercurywelcome.php"))
		.pause(1)
		.exec(http("request_1")
			.get("/black")
			.headers(headers_1)
			.resources(http("request_2")
			.get("/images/btn_signin.gif?osCsid=2bd9fbe07e9d5aa544f6becb0d74781c")
			.headers(headers_1))
			.check(status.is(404)))
		.pause(10)
		// Login
		object Login
		{
			val login=
		exec(http("request_3")
			.post("/login.php")
			.formParam("osCsid", "2bd9fbe07e9d5aa544f6becb0d74781c")
			.formParam("action", "process")
			.formParam("userName", "Testlab")
			.formParam("password", "testlab")
			.formParam("login.x", "12")
			.formParam("login.y", "9"))
		.pause(9)
		}
		val scn2=scenario("duringtest").during(5  minutes){exec(Login.login)}
		// logout
		.exec(http("request_4")
			.get("/mercurysignoff.php")
			.resources(http("request_5")
			.get("/black")
			.headers(headers_1)
			.check(status.is(404))))

	setUp(scn2.inject(atOnceUsers(1))).protocols(httpProtocol)
}