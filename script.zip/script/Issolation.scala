package sample2

import scala.concurrent.duration._
import java.util.concurrent.ThreadLocalRandom
import io.gatling.core.Predef._
import io.gatling.http.Predef._
import io.gatling.core.Predef._
import io.gatling.jdbc.Predef._

class Issolation extends Simulation {

	val httpProtocol = http
		.baseURL("http://computer-database.gatling.io")
		.inferHtmlResources(BlackList(""".*\.js""", """.*\.css""", """.*\.gif""", """.*\.jpeg""", """.*\.jpg""", """.*\.ico""", """.*\.woff""", """.*\.(t|o)tf""", """.*\.png"""), WhiteList())
		.acceptHeader("text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8")
		.acceptEncodingHeader("gzip, deflate")
		.acceptLanguageHeader("en-US,en;q=0.5")
		.userAgentHeader("Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:46.0) Gecko/20100101 Firefox/46.0")
	//val scn = scenario("Issolation")

	object Landing
		{
			val landing = exec(http("Landing page")
				.get("/"))
				.pause(4)
		}
	object Search
	{
		val feeder = csv("search.csv").random
				//val search = exec(http("request_1")
			val search = exec(http("Home").get("/"))
  			.feed(feeder)
  			.exec(http("Search")
			.get("/computers?f=${searchCriterion}")
					.check(css("a:contains('${searchComputerName}')", "href").saveAs("computerURL")))
  			.exec(http("Select").get("${computerURL}")
					.check(status.is(200)))
			.pause(14)
		polling
			.every(1 seconds)
			.exec(http("Page ${n}")
				.get("/computers?p=${n}")
				.check(status.is(session => 200 + ThreadLocalRandom.current.nextInt(2))))
	}

	object Edit
		{
			val edit = exec(http("Search for Lenovo")
			.get("/computers/4524"))
			.pause(19)
				.exec(
					http("Edit and save ")
					.post("/computers/4524")
					.formParam("name", "Lenovo-G50")
					.formParam("introduced", "2017-03-16")
					.formParam("discontinued", "2018-03-18")
					.formParam("company", "36")
				.check(status.is(session => 200 + ThreadLocalRandom.current.nextInt(2))))
		}
	//val userset1 =   scenario("Landing Page").exec(Landing.landing)
//	val userset2 = 	scenario(scenarioName = "Search").exec(Search.search)
	//val userset3 = scenario(scenarioName = "Edit").exec(Edit.edit)
	//setUp(scn.inject(nothingFor(4 seconds),
	//	atOnceUsers(10),
	//	rampUsers(10) over (5 seconds),constantUsersPerSec(20) during (15 seconds) randomized)).protocols(httpProtocol)

//testing

	//Loops
	//baseurl = "http://computer-database.gatling.io/computers?p=1"
	object Browse {

		def gotoPage(page: Int) = exec(http("Page " + page)
			.get("/computers?p=" + page))
			.pause(1)
		val browse = exec(gotoPage(0), gotoPage(1), gotoPage(2), gotoPage(3), gotoPage(4))
	}

	object Repeated
	{
		val repeated = repeat(5, "n")
		{
			exec(http("Page ${n}")
				.get("/computers?p=${n}")
				.check(status.is(session => 200 + ThreadLocalRandom.current.nextInt(2))))
				.pause(1)
		}
	}
	object Aslongas
	{
		//var idfeeder = csv("pagenos.csv").queue
		var numloop = new java.util.concurrent.atomic.AtomicInteger(0)
		val aslongas =
		asLongAs(_=> numloop.getAndIncrement() <3, exitASAP = false)
    {   feed(csv("pagenos.csv"))
        .exec(http("Page ${pageno}")
        .get("/computers?p=${pageno}")
        .check(status.is(session => 200 + ThreadLocalRandom.current.nextInt(2))))
        .pause(5)
			}
    }
  object Dbex
  {
    val dbex=
      jdbcFeeder(
        "jdbc:oracle:thin:@hostname:1521:XE","SYS", "sunita123",
        "select * from HR.emp_details_view")
  }
	val scn = scenario("scenario Name").exec(Landing.landing,Search.search ,Edit.edit)
//	val scn =scenario("scenario Name").exec(Landing.landing,Browse.browse,Repeated.repeated,Edit.edit,Search.search,Aslongas.aslongas)
  // val scn = scenario(scenarioName = "aslongas").exec(Aslongas.aslongas)
  //val scn = scenario(scenarioName = "DBEX").exec(Dbex.dbex)
  val tryMaxEdit = tryMax(2){exec(Aslongas.aslongas)}.exitHereIfFailed

 // val scn =scenario("Search") .during(300 seconds) { exec(Search.search) }
   // setUp(scn.inject(atOnceUsers(1))).protocols(httpProtocol)
  setUp(scn.inject(rampUsers(10) over (600 seconds))).protocols(httpProtocol)

	//testing - is
//set-1
	/*setUp(
		userset1.inject(rampUsers(10) over (10 seconds)),
		userset2.inject(rampUsers(30) over (10 seconds)),
	  userset3.inject(rampUsers(2) over (10 seconds))
	).protocols(httpProtocol)
	*/
	/*setUp(userset1.inject
				(
					nothingFor(4 seconds),
					atOnceUsers(10),
					rampUsers(10) over (5 seconds)
				),
				userset2.inject
				(
					constantUsersPerSec(20) during (15 seconds),
					constantUsersPerSec(20) during (15 seconds) randomized
				),
		userset3.inject
				(
					rampUsersPerSec(10) to 20 during (10 minutes),
					rampUsersPerSec(10) to 20 during (10 minutes) randomized

				)

				.protocols(httpProtocol))
				*/


}