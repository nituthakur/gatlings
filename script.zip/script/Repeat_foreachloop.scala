package looping


import scala.concurrent.duration._
import java.util.concurrent.ThreadLocalRandom
import io.gatling.core.Predef._
import io.gatling.http.Predef._
import io.gatling.core.Predef._
import io.gatling.jdbc.Predef._

class Repeat_foreachloop extends Simulation {

	val baseHttpConf = http.baseURL("").userAgentHeader("Gatling API Load Test").disableCaching

  val chained = scenario("my scenario")
    .exec(http("get google outside during")
      .get("http://google.com")
      .check(status.is(200)))
      .exec(_.set("myList", 0 until 0))

//    .during(10) {

      foreach("${myList}", "element") {

        exec(http("get google inside during")
          .get("http://google.com")
          .check(status.is(200)))
  //    }

    }

  setUp(chained.inject(atOnceUsers(50))).protocols(baseHttpConf)

}
	


	