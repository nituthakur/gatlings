package looping


import scala.concurrent.duration._
import java.util.concurrent.ThreadLocalRandom
import io.gatling.core.Predef._
import io.gatling.http.Predef._
import io.gatling.core.Predef._
import io.gatling.jdbc.Predef._

class Repeat_with_increment extends Simulation {

	val httpProtocol = http
		.baseURL("http://computer-database.gatling.io")
		.inferHtmlResources(BlackList(""".*\.js""", """.*\.css""", """.*\.gif""", """.*\.jpeg""", """.*\.jpg""", """.*\.ico""", """.*\.woff""", """.*\.(t|o)tf""", """.*\.png"""), WhiteList())
		.acceptHeader("text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8")
		.acceptEncodingHeader("gzip, deflate")
		.acceptLanguageHeader("en-US,en;q=0.5")
		.userAgentHeader("Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:46.0) Gecko/20100101 Firefox/46.0")
	
	object BaseUrl
	{	
	val baseurl = scenario("BaseURL")
		.exec(http("Home_page")
			.get("/"))
		.pause(5)
	}
	//Repeat for each value
	
	object Repeated
	{
		val repeated = repeat(5, "n")
		{
			exec(http("Page ${n}")
				.get("/computers?p=${n}")
				.check(status.is(session => 200 + ThreadLocalRandom.current.nextInt(2))))
				.pause(1)
		}
	}


	val rep = scenario("Repeat test1").exec(Repeated.repeated)
	//val base = scenario("repeat test2").repeat(3){exec(BaseUrl.baseurl)}
	setUp(
		
		//base.inject(atOnceUsers(1)),
		rep.inject(atOnceUsers(1))
		
		).protocols(httpProtocol)
	}