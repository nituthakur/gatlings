package demo

import scala.concurrent.duration._

import io.gatling.core.Predef._
import io.gatling.http.Predef._
import io.gatling.jdbc.Predef._

class FeederExample extends Simulation {

	val httpProtocol = http
		.baseURL("http://newtours.demoaut.com")
		.inferHtmlResources(BlackList(""".*\.js""", """.*\.css""", """.*\.gif""", """.*\.jpeg""", """.*\.jpg""", """.*\.ico""", """.*\.woff""", """.*\.(t|o)tf""", """.*\.png"""), WhiteList())
		.acceptHeader("text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8")
		.acceptEncodingHeader("gzip, deflate")
		.acceptLanguageHeader("en-US,en;q=0.5")
		.userAgentHeader("Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:46.0) Gecko/20100101 Firefox/46.0")

	val headers_1 = Map("Accept" -> "image/png,image/*;q=0.8,*/*;q=0.5")



	val scn = scenario("FeederExample")
		// PageLanding
		.exec(http("request_0")
			.get("/")
			.resources(http("request_1")
			.get( "/black")
			.headers(headers_1)
			.check(status.is(404))))
		.pause(7)
		// RegisterUser
		.exec(http("request_2")
			.get("/mercuryregister.php")
			.resources(http("request_3")
			.get( "/black")
			.headers(headers_1)
			.check(status.is(404))))
		.pause(69)
		.exec(http("request_4")
			.post("/mercurycreate_account.php")
			.formParam("mercury", "process")
			.formParam("firstName", "Hariprasad")
			.formParam("lastName", "panda")
			.formParam("phone", "9886383170")
			.formParam("userName", "pandahariprasad@gmail.com")
			.formParam("address1", "p2")
			.formParam("address2", "kaliniaggrahara")
			.formParam("city", "bangalore")
			.formParam("state", "Karnataka")
			.formParam("postalCode", "560076")
			.formParam("country", "92")
			.formParam("email", "TestDemo1")
			.formParam("password", "test123")
			.formParam("confirmPassword", "test123")
			.formParam("register.x", "28")
			.formParam("register.y", "13")
			.resources(http("request_5")
			.get( "/black")
			.headers(headers_1)
			.check(status.is(404))))

	setUp(scn.inject(atOnceUsers(1))).protocols(httpProtocol)
}