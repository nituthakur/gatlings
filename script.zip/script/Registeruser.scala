package jpetStore

import scala.concurrent.duration._

import io.gatling.core.Predef._
import io.gatling.http.Predef._
import io.gatling.jdbc.Predef._

class Registeruser extends Simulation {

	val httpProtocol = http
		.baseURL("http://localhost:8085")
		.inferHtmlResources(BlackList(""".*\.js""", """.*\.css""", """.*\.gif""", """.*\.jpeg""", """.*\.jpg""", """.*\.ico""", """.*\.woff""", """.*\.(t|o)tf""", """.*\.png"""), WhiteList())
		.acceptHeader("text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8")
		.acceptEncodingHeader("gzip, deflate, br")
		.acceptLanguageHeader("en-US,en;q=0.9,hi;q=0.8")
		.doNotTrackHeader("1")
		.userAgentHeader("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36")

	val headers_0 = Map("Upgrade-Insecure-Requests" -> "1")

	val headers_2 = Map(
		"Origin" -> "http://localhost:8085",
		"Upgrade-Insecure-Requests" -> "1")

    val uri1 = "http://localhost:8085/jpetstore"

	//val scn = scenario("Registeruser")
		// HomePage
		// ClickonSignin
			object Home {
		val home =
			exec(http("request_0")
				.get("/jpetstore")
				.headers(headers_0))
				.pause(15)
	}
		// RegisterNewUser
	//feeder Example witha csv format
		object Register
		{
			val userdata = csv("registeruser.csv")
			val register=
				exec(http("Register_New_User")
					.get("/jpetstore/shop/newAccountForm.shtml")
					.headers(headers_0))
			.pause(3).feed(userdata)
			.exec(http("PostThe Data for Register")
				.post("/jpetstore/shop/newAccount.shtml")
				.headers(headers_2)
				.formParam("validation", "new")
				.formParam("username", "${username}")
				.formParam("password", "${password}")
				.formParam("repeatedPassword", "${password}")
				.formParam("account.firstName", "${name}")
				.formParam("account.lastName", "Panda")
				.formParam("account.email", "${email}")
				.formParam("account.phone", "${phone}")
				.formParam("account.address1", "P2 25/35 Dharinicomforts")
				.formParam("account.address2", "Bangalore")
				.formParam("account.city", "Bangalore")
				.formParam("account.state", "Karnataka")
				.formParam("account.zip", "560076")
				.formParam("account.country", "India")
				.formParam("account.languagePreference", "english")
				.formParam("account.favouriteCategoryId", "FISH")
				.formParam("x", "30")
				.formParam("y", "8"))
			.pause(2)
		}
		// SignOut
	object Signout {
			val signout =
				exec(http("request_3")
					.get("/jpetstore/shop/signoff.shtml")
					.headers(headers_0))
		}
	val scn = scenario("registertest").exec(Register.register)
	setUp(scn.inject(atOnceUsers(1))).protocols(httpProtocol)
}