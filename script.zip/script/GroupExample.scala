
import scala.concurrent.duration._

import io.gatling.core.Predef._
import io.gatling.http.Predef._
import io.gatling.jdbc.Predef._

class GroupExample extends Simulation {

	val httpProtocol = http
		.baseURL("http://computer-database.gatling.io")
		.inferHtmlResources()
		.acceptHeader("text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8")
		.acceptEncodingHeader("gzip, deflate")
		.acceptLanguageHeader("en-US,en;q=0.5")
		.userAgentHeader("Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:46.0) Gecko/20100101 Firefox/46.0")


	//val scn = scenario("RecordedSimulation")
	object  PageLanding
	{
		val pagelanding =
		group("PageLanding"){
		exec(http("request_0")
			.get("/computers")
			.resources(http("request_1")
			.get("/favicon.ico")
			.check(status.is(404))))
		.pause(38)}}
		object Search
		{
			val search=
		group("Search"){
		exec(http("request_2")
			.get("/computers?f=lenovo")
			.resources(http("request_3")
			.get("/favicon.ico")
			.check(status.is(404))))
		.pause(7)}}

		object Edit
		{val edit =
		group("Edit"){
		exec(http("request_4")
			.get("/computers/484")
			.resources(http("request_5")
			.get("/favicon.ico")
			.check(status.is(404))))
		.pause(6)
		}}
		object Modify 
		{val modify =
		group("Modify"){
		exec(http("request_6")
			.post("/computers/484")
			.formParam("name", "lenovo thinkpad r400")
			.formParam("introduced", "2017-05-10")
			.formParam("discontinued", "2018-05-09")
			.formParam("company", "36")
			.resources(http("request_7")
			.get("/favicon.ico")
			.check(status.is(404))))
		}}
val scn = scenario("demo").exec(PageLanding.pagelanding,Search.search,Edit.edit,Modify.modify)
	setUp(scn.inject(atOnceUsers(1))).protocols(httpProtocol)
}